package com.example.nasaapi;


import com.google.gson.JsonObject;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.application.Platform;

public class ApiController {
    @FXML
    private TextField searchField;
    @FXML
    private Button searchButton;
    @FXML
    private Label statusLabel;
    @FXML
    private ImageView imageView;
    @FXML
    private Label summaryLabel;
    @FXML
    private Button moreDetailsButton;

    private UnsplashApiModel imageModel;
    private WikipediaApiModel wikiModel;
    private String currentSummary;

    @FXML
    public void initialize() {
        imageModel = new UnsplashApiModel();
        wikiModel = new WikipediaApiModel();

        searchField.setPromptText("Search anything to get information about it");

        searchButton.setOnAction(event -> fetchData());
        moreDetailsButton.setOnAction(event -> {
            try {
                MainApp.switchToDetailScene(currentSummary);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void fetchData() {
        String query = searchField.getText().trim();
        if (query.isEmpty()) {
            statusLabel.setText("Please enter a search term.");
            return;
        }

        statusLabel.setText("Status: Loading...");
        Task<Void> task = new Task<Void>() {
            @Override
            protected Void call() throws Exception {
                try {
                    // Fetch image data
                    JsonObject imageData = imageModel.fetchSearchResults(query);
                    JsonObject firstResult = imageData.getAsJsonArray("results").get(0).getAsJsonObject();
                    String imageUrl = firstResult.getAsJsonObject("urls").get("regular").getAsString();

                    // Fetch Wikipedia summary
                    JsonObject wikiData = wikiModel.fetchSummary(query);
                    String summary = wikiData.has("extract") && !wikiData.get("extract").isJsonNull()
                            ? wikiData.get("extract").getAsString()
                            : "No summary available";
                    currentSummary = summary;

                    Platform.runLater(() -> {
                        // Display image
                        imageView.setImage(new Image(imageUrl));
                        imageView.setVisible(true);

                        // Display Wikipedia summary
                        summaryLabel.setText("Summary: " + summary);
                        statusLabel.setText("Status: Loaded");
                    });
                } catch (Exception e) {
                    e.printStackTrace(); // Print stack trace to identify the error
                    Platform.runLater(() -> statusLabel.setText("Status: Error"));
                }
                return null;
            }
        };
        new Thread(task).start();
    }
}
