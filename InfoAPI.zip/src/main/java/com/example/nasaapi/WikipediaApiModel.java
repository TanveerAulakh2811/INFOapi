package com.example.nasaapi;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WikipediaApiModel {
    private static final String BASE_URL = "https://en.wikipedia.org/api/rest_v1/page/summary/";

    public JsonObject fetchSummary(String query) throws Exception {
        String urlString = BASE_URL + query.replace(" ", "_");
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        return JsonParser.parseString(response.toString()).getAsJsonObject();
    }
}
