package com.example.nasaapi;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class UnsplashApiModel {
    private static final String ACCESS_KEY = "CSSClBI_pLjfiMn0hx3UwIDnIuf3Q-5ke0oXpw0VwEk"; // Replace with your Unsplash API key
    private static final String BASE_URL = "https://api.unsplash.com/search/photos";

    public JsonObject fetchSearchResults(String query) throws Exception {
        String urlString = BASE_URL + "?query=" + query + "&client_id=" + ACCESS_KEY;
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();

        return JsonParser.parseString(response.toString()).getAsJsonObject();
    }
}
