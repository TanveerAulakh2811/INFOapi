package com.example.nasaapi;



import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class DetailViewController {

    @FXML
    private Label detailSummaryLabel;
    @FXML
    private Button backButton;
    @FXML
    private VBox detailContainer;

    public void setSummary(String summary) {
        detailSummaryLabel.setText(summary);
        detailSummaryLabel.setWrapText(true); // Ensure the label wraps text
    }

    @FXML
    public void initialize() {
        backButton.setOnAction(event -> {
            try {
                MainApp.switchToMainScene();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
