package com.example.nasaapi;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;

public class ApiView {
    @FXML
    private TextField searchField;
    @FXML
    private Button searchButton;
    @FXML
    private Label statusLabel;
    @FXML
    private ImageView imageView;

    private VBox root;




    public TextField getSearchField() {
        return searchField;
    }

    public Button getSearchButton() {
        return searchButton;
    }

    public Label getStatusLabel() {
        return statusLabel;
    }

    public ImageView getImageView() {
        return imageView;
    }
}
