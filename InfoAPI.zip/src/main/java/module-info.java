module com.example.nasaapi {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.google.gson;
    requires java.net.http;






    requires org.kordamp.bootstrapfx.core;
    requires javafx.web;

    opens com.example.nasaapi to javafx.fxml, com.google.gson;
    exports com.example.nasaapi;
}